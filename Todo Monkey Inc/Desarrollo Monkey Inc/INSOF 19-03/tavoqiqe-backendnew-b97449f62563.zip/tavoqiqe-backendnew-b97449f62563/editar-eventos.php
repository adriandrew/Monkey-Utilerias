<?php require_once('functions/session-start.php'); ?>
<?php require_once('functions/select-evento.php'); ?>
<!doctype html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Editar Evento</title>
	<link href="resources/css/style.css" rel="stylesheet" type="text/css" />
	<link href="resources/css/jquery-ui-1.10.3.custom.css" rel="stylesheet" type="text/css" />
	<script src="resources/js/jquery.min.js"></script>
	<script src="resources/js/jquery-ui-1.10.3.custom.min.js"></script>
	<script src="resources/js/validate-eventos.js"></script>
</head>
<body class="bg-wrap">
	<div class="wrap">
		<section id="content">
			<div class="container">
				<div class="content-main">
					<div id="content-section-elements" class="content-form clearfix">
						<div class="content-title">
							<h2 class="fix-section-title">Editar Evento</h2>
						</div>
						<form action="functions/edit-evento.php" method="post" id="form-eventos" autocomplete="off">
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="nombre">Nombre del evento</label>
									<input type="text" name="nombre" id="nombre" value="<?php echo $cargar['nombre']; ?>">
									<p id="error-input-nombre" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="fecha">Fecha del evento</label>
									<input type="text" name="fecha" id="jdate" value="<?php echo $cargar['fecha_str']; ?>">
									<p id="error-input-fecha" class="error-message" style="display:none;"><span></span></p>
								</div>
							</div>
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="evento">Descripción del evento</label>
									<textarea name="evento" id="evento" cols="34" rows="8"><?php echo $cargar['evento']; ?></textarea>
									<p id="error-input-evento" class="error-message" style="display:none;"><span></span></p>
								</div>
								<input type="submit" name="editar" id="button-save" class="button" value="Editar">
								<a href="eventos.php" id="button-cancel" class="cancel">Cancelar</a>
								<!--<input type="submit" name="cancelar" id="cancel-edit" class="button" value="Cancelar">-->
								<input type="hidden" name="id" value="<?php echo $cargar['id']; ?>" style="width:20px;">
							</div>
						</form>
					</div>
				</div>
			</div>
		</section>
	</div>
	<script>
		$(document).ready(function(){
			 $.datepicker.regional['es'] = {
			closeText: 'Cerrar',
			prevText: '<Ant',
			nextText: 'Sig>',
			currentText: 'Hoy',
			monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
			monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
			dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
			dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
			dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
			weekHeader: 'Sm',
			dateFormat: 'dd/mm/yy',
			firstDay: 1,
			isRTL: false,
			showMonthAfterYear: false,
			yearSuffix: ''
		};
		$.datepicker.setDefaults($.datepicker.regional['es']);
		});
	</script>

	<!-- datepicker -->
	<script>
		$(document).ready(function(){
			$("#jdate").datepicker({
				numberOfMonths: 1,
				dateFormat: "DD dd 'de' MM 'del' yy",
			});
		});
	</script>
</body>
</html>