$(document).ready(function(){
	$('#button-save').click(function(){

		var nombre = $('#nombre').val();
		var fecha = $('#jdate').val();
		var noticia = $('#noticia').val();

		if(nombre == ""){
			$('#error-input-nombre span').html("Porfavor ingrese el nombre de la noticia");
			$('#error-input-nombre').fadeIn('slow');
			$('#nombre').focus();
			return false;
		}else{
			$('#error-input-nombre').fadeOut('slow');
		}
		if(fecha == ""){
			$('#error-input-fecha span').html("Porfavor ingrese la fecha de la noticia");
			$('#error-input-fecha').fadeIn('slow');
			$('#fecha').focus();
			return false;
		}else{
			$('#error-input-fecha').fadeOut('slow');
		}
		if(noticia == ""){
			$('#error-input-noticia span').html("Porfavor ingrese una descripción para la noticia");
			$('#error-input-noticia').fadeIn('slow');
			$('#noticia').focus();
			return false;
		}else{
			$('#error-input-noticia').out('slow');
		}

	});
});