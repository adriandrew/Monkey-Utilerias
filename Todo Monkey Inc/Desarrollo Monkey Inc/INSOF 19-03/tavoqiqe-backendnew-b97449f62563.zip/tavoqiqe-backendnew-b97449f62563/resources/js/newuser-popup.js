;(function($) {
	$(function() {
		$('#popup-trigger').bind('click', function(e) {
			e.preventDefault();
			$('#popup-target').bPopup();
		});
		$('#button-login-cancel').bind('click', function(e) {
			e.preventDefault();
			$('#popup-target').bPopup().close();
		});
	});
})(jQuery);
