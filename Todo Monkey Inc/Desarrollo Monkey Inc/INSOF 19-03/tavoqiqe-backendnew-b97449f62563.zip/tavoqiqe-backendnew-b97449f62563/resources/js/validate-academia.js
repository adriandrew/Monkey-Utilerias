$(document).ready(function(){
	$('#button-save').click(function(){

		var nombre = $('#nombre').val();
		var cargo = $('#cargo').val();
		var cubiculo = $('#cubiculo').val();
		var hora = $('#hora').val();
		var telefono = $('#telefono').val();
		var email = $('#email').val();
		var area = $('#area').val();
		var certificacion = $('#certificacion').val();

		if(nombre == ""){
			$('#error-input-nombre span').html("Por favor ingrese el nombre del profesor");
			$('#error-input-nombre').fadeIn('slow');
			$('#nombre').focus();
			return false;
		}else{
			$('#error-input-nombre').fadeOut('slow');
		}
		if(cargo == ""){
			$('#error-input-cargo span').html("Por favor ingrese el cargo del profesor");
			$('#error-input-cargo').fadeIn('slow');
			$('#cargo').focus();
			return false;
		}else{
			$('#error-input-cargo').fadeOut('slow');
		}
		if(cubiculo == ""){
			$('#error-input-cubiculo span').html("Por favor ingrese el cubiculo del profesor");
			$('#error-input-cubiculo').fadeIn('slow');
			$('#cubiculo').focus();
			return false;
		}else{
			$('#error-input-cubiculo').fadeOut('slow');
		}
		if(hora == ""){
			$('#error-input-hora span').html("Por favor ingrese ingrese el horario del profesor");
			$('#error-input-hora').fadeIn('slow');
			$('#hora').focus();
			return false;
		}else{
			$('#error-input-hora').fadeOut('slow');
		}
		if(telefono == ""){
			$('#error-input-telefono span').html("Por favor ingrese el teléfono del profesor");
			$('#error-input-telefono').fadeIn('slow');
			$('#telefono').focus();
			return false;
		}else{
			$('#error-input-telefono').fadeOut('slow');
		}
		if(email == ""){
			$('#error-input-email span').html("Por favor ingrese el correo del profesor");
			$('#error-input-email').fadeIn('slow');
			$('#email').focus();
			return false;
		}else{
			$('#error-input-email').fadeOut('slow');
		}
		if(area == ""){
			$('#error-input-area span').html("Por favor ingrese el área de interés del profesor");
			$('#error-input-area').fadeIn('slow');
			$('#area').focus();
			return false;
		}else{
			$('#error-input-area').fadeOut('slow');
		}
		if(certificacion == ""){
			$('#error-input-certificacion span').html("Por favor ingrese la certificación del profesor");
			$('#error-input-certificacion').fadeIn('slow');
			$('#certificacion').focus();
			return false;
		}else{
			$('#error-input-certificacion').fadeOut('slow');
		}

	});
});