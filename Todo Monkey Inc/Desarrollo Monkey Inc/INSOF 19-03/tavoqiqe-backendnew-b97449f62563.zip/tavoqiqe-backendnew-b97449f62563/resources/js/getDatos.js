$('#flipPad a.getLista').bind('click', getLista);

function getLista(){
	window.tabla = $(this).attr('id');
	$.getJSON('functions/function-getDatos.php?tabla='+tabla+'&callback=?', function(json){
		console.log(json);
		window.listadoB = json;
		injectLista(listadoB);
	});
}

function injectLista(listado){
	if(tabla == 'movil_usuarios'){
		$.each(listado.items, function(clave, valor){
			$('.title-consultaqs').html('Usuarios');
			$('ul.list-qs').append('<li><div class="thumb-qs"><img src="resources/images/happy-face.png"></div><div class="top-qs"><p>'+valor.nombre+' '+valor.apellidos+'</p></div><div class="bottom-qs"><p>Usuario: '+valor.usuario+'<br>Correo: '+valor.email+'</p></div></li>');
		});
	}
	if(tabla == 'movil_academia'){
		$('.title-consultaqs').html("Academia");
		$.each(listado.items, function(clave, valor){
			$('ul.list-qs').append('<li><div class="thumb-qs"><img src="'+valor.imagen+'"></div><div class="top-qs"><p>'+valor.nombre+'</p></div><div class="bottom-qs"><p>'+valor.cargo+'</p></div></li>');
		});
	}
	if(tabla == 'movil_noticia'){
		$('.title-consultaqs').html("Noticias");
		$.each(listado.items, function(clave, valor){
			$('ul.list-qs').append('<li><div class="thumb-qs"><img src="'+valor.imagen+'"></div><div class="top-qs"><p>'+valor.nombre+'</p></div><div class="bottom-qs"><p>Fecha de la noticia: <br>'+valor.fecha_str+'</p></div></li>');
		});
	}
	if(tabla == 'movil_evento'){
		$('.title-consultaqs').html("Eventos");
		$.each(listado.items, function(clave, valor){
			$('ul.list-qs').append('<li><div class="thumb-qs"><img src="'+valor.imagen+'"></div><div class="top-qs"><p>'+valor.nombre+'</p></div><div class="bottom-qs"><p>Fecha de la noticia: <br>'+valor.fecha_str+'</p></div></li>');
		});
	}
}