$(document).ready(function(){
	$('#button-login').click(function(){

		var usuario = $('#usuario').val();
		var contrasena = $('#contrasena').val();

		if(usuario == ""){
			$('#error-user-login span').html('Porfavor ingrese su nombre de usuario');
			$('#error-user-login').fadeIn('slow');
			$('#usuario').focus();
			return false;
		}else{
			$('#error-user-login').fadeOut('slow');
		}
		if(contrasena == ""){
			$('#error-password-login span').html('Porfavor ingrese su contraseña');
			$('#error-password-login').fadeIn('slow');
			$('#contrasena').focus();
			return false;
		}else{
			$('#error-password-login').fadeOut('slow');
		}

	});//click
});//document
