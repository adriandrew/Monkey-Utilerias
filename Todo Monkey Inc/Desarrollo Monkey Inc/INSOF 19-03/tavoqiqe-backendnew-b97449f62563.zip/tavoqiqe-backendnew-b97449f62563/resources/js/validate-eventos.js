$(document).ready(function(){
	$('#button-save').click(function(){

		var nombre = $('#nombre').val();
		var fecha = $('#fecha').val();
		var evento = $('#evento').val();

		if(nombre == ""){
			$('#error-input-nombre span').html("Porfavor ingrese el nombre del evento");
			$('#error-input-nombre').fadeIn('slow');
			$('#nombre').focus();
			return false;
		}else{
			$('#error-input-nombre').fadeOut('slow');
		}
		if(fecha == ""){
			$('#error-input-fecha span').html("Porfavor ingrese la fecha del evento");
			$('#error-input-fecha').fadeIn('slow');
			$('#fecha').focus();
			return false;
		}else{
			$('#error-input-fecha').fadeOut('slow');
		}
		if(evento == ""){
			$('#error-input-evento span').html("Porfavor ingrese una descripción para el evento");
			$('#error-input-evento').fadeIn('slow');
			$('#evento').focus();
			return false;
		}else{
			$('#error-input-evento').out('slow');
		}

	});
});