<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="<?php echo $strLoginInterface . ' ' . $strPoweredBy . ' phpSecurePages'; ?>">
<meta name="keywords" content="phpSecurePages">
<title>Login | Backend</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="resources/css/style.css" rel="stylesheet" type="text/css" />
<link href="resources/css/responsive.css" rel="stylesheet" type="text/css" />
<script>
<!--
//  ------ check form ------
function checkData() {
        var f1 = document.forms[0];
        var wm = "<?php echo $strJSHello; ?>\n\r\n";
        var noerror = 1;

        // --- entered_login ---
        var t1 = f1.entered_login;
        if (t1.value == "" || t1.value == " ") {
                wm += "<?php echo $strLogin; ?>\r\n";
                noerror = 0;
        }

        // --- entered_password ---
        var t1 = f1.entered_password;
        if (t1.value == "" || t1.value == " ") {
                wm += "<?php echo $strPassword; ?>\r\n";
                noerror = 0;
        }

        // --- check if errors occurred ---
        if (noerror == 0) {
                alert(wm);
                return false;
        }
        else return true;
}
//-->
</script>
<style>
#error{margin:1em auto;background:#FA4956;color:#FFFFFF;border:8px solid #FA4956;font-weight:bold;width:500px;text-align:center;position:relative;}
#entry{margin:2em auto;background:#fff;border:8px solid #eee;width:500px;text-align:left;position:relative;}
#entry a, #entry a:visited{color:#0283b2;}
#entry a:hover{color:#111;}
#entry h1{text-align:center;background:#3B8CCA;color:#fff;font-size:16px;padding:16px 25px;margin:0 0 1.5em 0;border-bottom:1px solid #007dab;}
#entry p{text-align:center;}
#entry div{margin:.5em 25px;background:#eee;padding:4px;text-align:right;position:relative;}
#entry label{float:left;line-height:30px;padding-left:10px;}
#entry .field{border:1px solid #ccc;width:280px;font-size:12px;line-height:1em;padding:4px;}
#entry div.submit{background:none;margin:1em 25px;text-align:center;}
#entry div.submit label{float:none;display:inline;font-size:11px;}
#entry button{border:0;padding:0 30px;height:30px;line-height:30px;text-align:center;font-size:16px;font-weight:bold;color:#fff;background:#3B8CCA;cursor:pointer;}
</style>
</head>
<body class="bg-wrap">

<!-- ------ Have you set up phpSP with no users?  ------ -->
        <?php if ($useDatabase == false AND $useData == true AND $cfgLogin[1] == "") echo '<p style="font-family:arial;font-size:22px;color:red;font-weight:bold;">WEBMASTER: It looks like you have no users or passwords set up! <br>
        <br><span style="font-size:18px;">If you are not using a database, make sure you have configured<br>at least one user in config.php (around line 85).</span></p>'; ?>
<!-- ------ Initial Setup (No Users) check ends here ------ -->

<!-- wrap -->
    <div class="wrap">
        <!-- container-login -->
        <div class="container-login">
            <!-- content-login -->
            <div class="content-login">
                <div class="login-logo">
                    <h1><img src="resources/images/logo.png" height="80" width="160" alt=""></h1>
                </div>
                <div class="top-login">
                    <h2 class="login-ribbon">
                        <span>Por favor ingrese con su cuenta</span>
                    </h2>
                    <a href="javascript:;" id="popup-trigger" class="new-user">
                        <span>Agregar nuevo usuario!</span>
                    </a>
                </div>
                <div class="content-login-form clearfix">
                    <form action="<?php echo $_SERVER['REQUEST_URI'] ?>" method="post" id="form-login" onSubmit="return checkData()" autocomplete="off">
                        <div class="control-group">
                            <label class="control-label" for="usuario">Nombre de usuario</label>
                            <input class="control-input-login" type="text" name="entered_login" id="usuario" class="field required" autofocus>
                            <!--<p id="error-user-login" class="error-message" style="display:none;"><span></span></p>-->
                        </div>
                        <div class="control-group">
                            <label class="control-label" for="contrasena">Contraseña</label>
                            <input class="control-input-login" type="password" name="entered_password" id="contrasena" class="field required">
                            <p id="error-password-login" class="error-message" style="display:none;"><span></span></p>
                        </div>
                        <input type="submit" name="entrar" id="button-login" class="button button-login" value="Entrar">
                    </form>
                </div>
            </div>
            <!-- end content-login -->
        </div>
        <!-- end container-login -->
        <?php require_once('new-user.php'); ?>
    </div>
    <!-- end wrap -->

<?php
// check for error messages
if ($phpSP_message) {
        echo '<div id="error" style="margin-top:25px; font-size:14px; background-color:#2b8cbe; border:8px solid #2b8cbe">'.$phpSP_message.'</div>';
        }
?>
<script src="resources/js/jquery.min.js"></script>
<script src="resources/js/jquery.bpopup.min.js"></script>
<script src="resources/js/newuser-popup.js"></script>
<script>
<!--
document.forms[0].entered_login.select();
document.forms[0].entered_login.focus();
//-->
</script>
</body>
</html>
