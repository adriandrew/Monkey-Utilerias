<?php require_once('templates/header.php'); ?>
		<!-- content -->
		<section id="content">
			<div class="container">
				<div class="content-main">
					<div id="content-section-elements" class="content-form clearfix">
						<div class="content-title">
							<span class="showHide">
								<a href="javascript:;" class="show"><img src="resources/images/row_down.png" height="17" width="17" alt=""></a>
								<a href="javascript:;" class="hide hide-row"><img src="resources/images/row_up.png" height="17" width="17" alt=""></a>
							</span>
							<h2 class="fix-section-title">Registro Eventos</h2>
						</div>
						<form action="functions/save-evento.php" method="post" id="form-eventos" autocomplete="off" enctype="multipart/form-data">
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="nombre">Nombre del evento</label>
									<input type="text" name="nombre" id="nombre">
									<p id="error-input-nombre" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="fecha">Fecha del evento</label>
									<input type="text" name="fecha" id="jdate">
									<p id="error-input-fecha" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="imagen">Imagen:</label>
									<div class="file-wrapper">
										<input type="file" name="imagen" id="imagen_evento">
									</div>
								</div>
							</div>
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="evento">Descripción del evento</label>
									<textarea name="evento" id="evento" cols="34" rows="8"></textarea>
									<p id="error-input-evento" class="error-message" style="display:none;"><span></span></p>
								</div>
								<input type="submit" name="guardar" id="button-save" class="button" value="Guardar">
							</div>
						</form>
					</div>
					<div id="content-section-elements" class="content-table">
						<div class="content-title">
							<span class="showHide">
								<a href="javascript:;" class="show hide-row"><img src="resources/images/row_down.png" height="17" width="17"></a>
								<a href="javascript:;" class="hide"><img src="resources/images/row_up.png" height="17" width="17"></a>
							</span>
							<h2 class="fix-section-title">Tabla Eventos</h2>
						</div>
						<div class="holder"></div>
						<?php require_once('tables/table-eventos.php'); ?>
					</div>
				</div>
			</div>
		</section>
		<!-- end content -->
		<?php require_once('templates/footer.php'); ?>
	</div>
	<!-- end wrap -->
</body>
</html>