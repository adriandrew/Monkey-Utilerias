<?php require_once('functions/session-start.php'); ?>
<?php require_once('functions/select-usuario.php'); ?>
<!doctype html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Editar Academia</title>
	<link href="resources/css/style.css" rel="stylesheet" type="text/css" />
	<script src="resources/js/jquery-2.0.3.min.js"></script>
	<script src="resources/js/validate-academia.js"></script>
</head>
<body class="bg-wrap">
	<div class="wrap">
		<section id="content">
			<div class="container">
				<div class="content-main">
					<div id="content-section-elements" class="content-form clearfix">
						<div class="content-title">
							<h2 class="fix-section-title">Editar Usuario</h2>
						</div>
						<form action="functions/edit-user.php" method="post" id="form-academia" autocomplete="off">
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="nombre">Nombre</label>
									<input type="text" name="nombre" id="nombre" value="<?php echo $cargar['nombre']; ?>">
									<!--<p id="error-input-nombre" class="error-message" style="display:none;"><span></span></p>-->
								</div>
								<div class="control-group">
									<label class="control-label" for="apellidos">Apellidos</label>
									<input type="text" name="apellidos" id="apellidos" value="<?php echo $cargar['apellidos']; ?>">
									<!--<p id="error-input-apellidos" class="error-message" style="display:none;"><span></span></p>-->
								</div>
								<div class="control-group">
									<label class="control-label" for="email">Email</label>
									<input type="text" name="email" id="email" value="<?php echo $cargar['email']; ?>">
									<!--<p id="error-input-email" class="error-message" style="display:none;"><span></span></p>-->
								</div>
							</div>
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="usuario">Nombre de usuario</label>
									<input type="text" name="usuario" id="usuario" value="<?php echo $cargar['usuario']; ?>">
									<!--<p id="error-input-area" class="error-message" style="display:none;"><span></span></p>-->
								</div>
								<div class="control-group">
									<label class="control-label" for="contrasena">Contraseña</label>
									<input type="text" name="contrasena" id="contrasena" value="<?php echo $cargar['contrasena']; ?>">
									<!--<p id="error-input-certificacion" class="error-message" style="display:none;"><span></span></p>-->
								</div>
								<div class="control-group" style="display:inline-block;">
									<label class="control-label" for="sexo">Sexo</label>
									<select name="sexo" id="sexo" class="fix-select-width" style="width:169px;">
										<?php echo ($cargar['sexo'] == 'h') ?
										"<option value='$_SESSION[sexo]'>Hombre</option><option value='m'>Mujer</option>" :
										"<option value='$_SESSION[sexo]'>Mujer</option><option value='h'>Hombre</option>" ?>
									</select>
								</div>
								<div class="control-group" style="display:inline-block; margin-bottom:20px;">
									<label class="control-label" for="sexo">Nivel</label>
									<select name="nivel" id="nivel" class="fix-select-width" style="width:169px;">
										<?php echo ($cargar['nivel'] == '1') ?
										"<option value='$cargar[nivel]'>Administrador</option><option value='2'>Usuario</option>" :
										"<option value='$cargar[nivel]'>Usuario</option><option value='1'>Administrador</option>" ?>
									</select>
								</div>
								<br>
								<input type="submit" name="editar" id="button-save" class="button" value="Editar">
								<a href="editar-usuarios.php" id="button-cancel" class="cancel">Cancelar</a>
								<input type="hidden" name="id" value="<?php echo $cargar['id']; ?>" style="width:20px; float:left;">
							</div>
						</form>
					</div>
				</div>
			</div>
		</section>
	</div>
</body>
</html>