<?php require_once('templates/header.php'); ?>
		<!-- content -->
		<section id="content">
			<div class="container">
				<div class="content-main">
					<div id="content-section-elements" class="content-form clearfix">
						<div class="content-title">
							<span class="showHide">
								<a href="javascript:;" class="show"><img src="resources/images/row_down.png" height="17" width="17" alt=""></a>
								<a href="javascript:;" class="hide hide-row"><img src="resources/images/row_up.png" height="17" width="17" alt=""></a>
							</span>
							<h2 class="fix-section-title">Registro Academia</h2>
						</div>
						<form action="functions/save-academia.php" method="post" id="form-academia" autocomplete="off" enctype="multipart/form-data">
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="nombre">Nombre del Profesor</label>
									<input type="text" name="nombre" id="nombre">
									<p id="error-input-nombre" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="cargo">Cargo</label>
									<input type="text" name="cargo" id="cargo">
									<p id="error-input-cargo" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="cubiculo">Cubículo</label>
									<input type="text" name="cubiculo" id="cubiculo">
									<p id="error-input-cubiculo" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="hora">Horario en cubículo</label>
									<input type="text" name="hora" id="hora">
									<p id="error-input-hora" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="telefono">Teléfono</label>
									<input type="text" name="telefono" id="telefono">
									<p id="error-input-telefono" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="email">E-mail</label>
									<input type="text" name="email" id="email">
									<p id="error-input-email" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<div class="file-wrapper">
										<span style="font-size:13px; margin-right:5px;">Imagen: </span><input type="file" name="imagen" id="imagen_academia">
									</div>
								</div>
							</div>
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="area">Área de interés</label>
									<textarea name="area" id="area" cols="34" rows="8"></textarea>
									<p id="error-input-area" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="certificacion">Área de certificación y/o especialidad</label>
									<textarea name="certificacion" id="certificacion" cols="34" rows="8"></textarea>
									<p id="error-input-certificacion" class="error-message" style="display:none;"><span></span></p>
								</div>
								<input type="submit" name="guardar" id="button-save" class="button" value="Guardar">
							</div>
						</form>
					</div>
					<div id="content-section-elements" class="content-table">
						<div class="content-title">
							<span class="showHide">
								<a href="javascript:;" class="show hide-row"><img src="resources/images/row_down.png" height="17" width="17"></a>
								<a href="javascript:;" class="hide"><img src="resources/images/row_up.png" height="17" width="17"></a>
							</span>
							<h2 class="fix-section-title">Tabla Academia</h2>
						</div>
						<div class="holder"></div>
						<?php require_once('tables/table-academia.php'); ?>
					</div>
				</div>
			</div>
		</section>
		<!-- end content -->
		<?php require_once('templates/footer.php'); ?>
	</div>
	<!-- end wrap -->
</body>
</html>