<div id="popup-target" class="container" style="width:550px; display:none;">
	<div class="content-main">
		<div id="content-section-elements" class="content-form clearfix">
			<div class="content-title">
				<h2 class="fix-section-title" style="width:98%;">Registrar Nuevo Usuario</h2>
			</div>
			<form action="functions/save-user.php" method="post" id="form-newuser" autocomplete="off">
				<div class="float-container-form" style="margin-left:15px; width:45%;">
					<div class="control-group">
						<label class="control-label" for="nombre">Nombre</label>
						<input type="text" name="nombre" id="nombre">
						<p id="error-input-nombre" class="error-message" style="display:none;"><span></span></p>
					</div>
					<div class="control-group">
						<label class="control-label" for="apellidos">Apellidos</label>
						<input type="text" name="apellidos" id="apellidos">
						<p id="error-input-apellidos" class="error-message" style="display:none;"><span></span></p>
					</div>
					<div class="control-group">
						<label class="control-label" for="email">Email</label>
						<input type="text" name="email" id="email">
						<p id="error-input-email" class="error-message" style="display:none;"><span></span></p>
					</div>
				</div>
				<div class="float-container-form">
					<div class="control-group">
						<label class="control-label" for="usuario">Nombre de usuario</label>
						<input type="text" name="usuario" id="usuario">
						<p id="error-input-usuario" class="error-message" style="display:none;"><span></span></p>
					</div>
					<div class="control-group">
						<label class="control-label" for="contrasena">Contraseña</label>
						<input type="password" name="contrasena" id="contrasena">
						<p id="error-input-contrasena" class="error-message" style="display:none;"><span></span></p>
					</div>
					<div class="control-group">
						<label class="control-label" for="sexo">Sexo</label>
						<select name="sexo" id="sexo" class="fix-select-width">
							<option value="h">Hombre</option>
							<option value="m">Mujer</option>
						</select>
					</div>
					<div class="control-group" style="display:none;">
						<label class="control-label" for="nivel">Nivel de usuario</label>
						<select name="nivel" id="nivel" class="fix-select-width">
							<option value="2">Usuario</option>
						</select>
					</div>
					<div class="action-control">
						<input type="submit" name="registrar" id="button-save" class="button" value="Registrar">
						<a href="javascript:;" id="button-login-cancel" style="font-size:13px; padding-top:8px; display:inline-block;">Cancelar</a>
						<!--<input type="submit" name="cancel" id="button-cancel" class="button" value="Cancelar">-->
					</div>
				</div>
			</form>
		</div>
	</div>
</div>