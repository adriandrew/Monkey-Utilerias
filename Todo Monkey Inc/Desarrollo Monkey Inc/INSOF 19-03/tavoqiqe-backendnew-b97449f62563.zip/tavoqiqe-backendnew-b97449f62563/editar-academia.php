<?php require_once('functions/session-start.php'); ?>
<?php require_once('functions/select-academia.php'); ?>
<!doctype html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Editar Academia</title>
	<link href="resources/css/style.css" rel="stylesheet" type="text/css" />
	<script src="resources/js/jquery-2.0.3.min.js"></script>
	<script src="resources/js/validate-academia.js"></script>
</head>
<body class="bg-wrap">
	<div class="wrap">
		<section id="content">
			<div class="container">
				<div class="content-main">
					<div id="content-section-elements" class="content-form clearfix">
						<div class="content-title">
							<h2 class="fix-section-title">Editar Profesor</h2>
						</div>
						<form action="functions/edit-academia.php" method="post" id="form-academia" autocomplete="off">
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="nombre">Nombre del Profesor</label>
									<input type="text" name="nombre" id="nombre" value="<?php echo $cargar['nombre']; ?>">
									<p id="error-input-nombre" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="cargo">Cargo</label>
									<input type="text" name="cargo" id="cargo" value="<?php echo $cargar['cargo']; ?>">
									<p id="error-input-cargo" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="cubiculo">Cubículo</label>
									<input type="text" name="cubiculo" id="cubiculo" value="<?php echo $cargar['cubiculo']; ?>">
									<p id="error-input-cubiculo" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="hora">Horario en cubículo</label>
									<input type="text" name="hora" id="hora" value="<?php echo $cargar['hora']; ?>">
									<p id="error-input-hora" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="telefono">Teléfono</label>
									<input type="text" name="telefono" id="telefono" value="<?php echo $cargar['telefono']; ?>">
									<p id="error-input-telefono" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="email">E-mail</label>
									<input type="text" name="email" id="email" value="<?php echo $cargar['email']; ?>">
									<p id="error-input-email" class="error-message" style="display:none;"><span></span></p>
								</div>
							</div>
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="area">Área de interés</label>
									<textarea name="area" id="area" cols="34" rows="8"><?php echo $cargar['area']; ?></textarea>
									<p id="error-input-area" class="error-message" style="display:none;"><span></span></p>
								</div>
								<div class="control-group">
									<label class="control-label" for="certificacion">Área de certificación y/o especialidad</label>
									<textarea name="certificacion" id="certificacion" cols="34" rows="8"><?php echo $cargar['certificacion']; ?></textarea>
									<p id="error-input-certificacion" class="error-message" style="display:none;"><span></span></p>
								</div>
								<input type="submit" name="editar" id="button-save" class="button" value="Editar">
								<a href="academia.php" id="button-cancel" class="cancel">Cancelar</a>
								<!--<input type="submit" name="cancelar" id="cancel-edit" class="button" value="Cancelar">-->
								<input type="hidden" name="id" value="<?php echo $cargar['id']; ?>" style="width:20px;">
							</div>
						</form>
					</div>
				</div>
			</div>
		</section>
	</div>
</body>
</html>