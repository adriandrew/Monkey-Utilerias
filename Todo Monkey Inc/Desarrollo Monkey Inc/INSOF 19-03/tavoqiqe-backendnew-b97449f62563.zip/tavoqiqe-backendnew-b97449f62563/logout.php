<?PHP
        $logout = true;
        $cfgProgDir = 'resources/phpSecurePages/';
        include($cfgProgDir . "secure.php");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="<?php echo $strLoginInterface . ' ' . $strPoweredBy . ' phpSecurePages'; ?>">
<meta name="keywords" content="phpSecurePages">
<title>Logout | BackEnd</title>

<link href="resources/css/style.css" rel="stylesheet" type="text/css" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
body{text-align:center;}
#logout{margin:1em auto;background:#4a6b2d;color:#FFFFFF;border:8px solid #4a6b2d;font-weight:bold;width:500px;text-align:center;position:relative;}
.container-logout{-webkit-box-shadow: 0 1px 4px rgba(0,0,0,0.3), 0 0 40px rgba(0,0,0,0.1);
-moz-box-shadow: 0 1px 4px rgba(0,0,0,0.3), 0 0 40px rgba(0,0,0,0.1);
box-shadow: 0 1px 4px rgba(0,0,0,0.3), 0 0 40px rgba(0,0,0,0.1);}
</style>
</head>
<body class="bg-wrap">

<div class="container-logout" style="width:40%; margin:0 auto; margin-top:10px; height:auto; padding:10px; background-color:#fff;">
	<!-- Place your logo here -->
	        <P style="margin-top:30px;"><IMG SRC="resources/images/logo.png" ALT="phpSecurePages logo"></P>
	<!-- Place your logo here -->




	<div id="logout" style="margin-top:25px; margin-bottom:25px; font-size:14px; background-color:#2b8cbe; border:8px solid #2b8cbe;">Has cerrado sesión</div>

	<p style="margin-bottom:20px; font-size:14px;"><a href="index.php">Voler a inicio</a></p>
</div>



</body>
</html>
