<?php require_once('templates/header.php'); ?>
		<!-- content -->
		<section id="content">
			<div class="container">
				<div class="content-main">
					<div id="content-section-elements" class="content-form clearfix">
						<div class="content-title">
							<span class="showHide">
								<a href="javascript:;" class="show"><img src="resources/images/row_down.png" height="17" width="17" alt=""></a>
								<a href="javascript:;" class="hide hide-row"><img src="resources/images/row_up.png" height="17" width="17" alt=""></a>
							</span>
							<h2 class="fix-section-title">Editar mi información</h2>
						</div>
						<form action="functions/edit-user.php?btl" method="post" id="form-usuarios" autocomplete="off">
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="nombre">Nombre</label>
									<input type="text" name="nombre" id="nombre" value="<?php echo $_SESSION['nombre']; ?>">
									<!--<p id="error-input-nombre" class="error-message" style="display:none;"><span></span></p>-->
								</div>
								<div class="control-group">
									<label class="control-label" for="apellidos">Apellidos</label>
									<input type="text" name="apellidos" id="apellidos" value="<?php echo $_SESSION['apellidos']; ?>">
									<!--<p id="error-input-apellidos" class="error-message" style="display:none;"><span></span></p>-->
								</div>
								<div class="control-group">
									<label class="control-label" for="email">Email</label>
									<input type="text" name="email" id="email" value="<?php echo $_SESSION['email']; ?>">
									<!--<p id="error-input-email" class="error-message" style="display:none;"><span></span></p>-->
								</div>
							</div>
							<div class="float-container-form">
								<div class="control-group">
									<label class="control-label" for="usuario">Nombre de usuario</label>
									<input type="text" name="usuario" id="usuario" value="<?php echo $_SESSION['usuario']; ?>">
									<!--<p id="error-input-area" class="error-message" style="display:none;"><span></span></p>-->
								</div>
								<div class="control-group">
									<label class="control-label" for="contrasena">Contraseña</label>
									<input type="text" name="contrasena" id="contrasena" value="<?php echo $_SESSION['contrasena']; ?>">
									<!--<p id="error-input-certificacion" class="error-message" style="display:none;"><span></span></p>-->
								</div>
								<div class="control-group" style="display:inline-block;">
									<label class="control-label" for="sexo">Sexo</label>
									<select name="sexo" id="sexo" class="fix-select-width" style="width:169px;">
										<?php echo ($_SESSION['sexo'] == 'h') ?
										"<option value='$_SESSION[sexo]'>Hombre</option><option value='m'>Mujer</option>" :
										"<option value='$_SESSION[sexo]'>Mujer</option><option value='h'>Hombre</option>" ?>
									</select>
								</div>
								<?php if($_SESSION['nivel'] == '1') { ?>
								<div class="control-group" style="display:inline-block; margin-bottom:20px;">
									<label class="control-label" for="sexo">Nivel</label>
									<select name="nivel" id="nivel" class="fix-select-width" style="width:169px;">
										<?php echo ($_SESSION['nivel'] == '1') ?
										"<option value='$_SESSION[nivel]'>Administrador</option><option value='2'>Usuario</option>" :
										"<option value='$_SESSION[nivel]'>Usuario<option><option value='1'>Administrador</option>" ?>
									</select>
								</div>
								<?php }else{ ?>
								<div class="control-group" style="display:none; margin-bottom:20px;">
									<label class="control-label" for="sexo">Nivel</label>
									<select name="nivel" id="nivel" class="fix-select-width" style="width:169px;">
										<option value="2">Usuario</option>
									</select>
								</div>
								<?php } ?>
								<br>
								<input type="submit" name="editar" id="button-save" class="button" value="Editar">
								<a href="index.php" id="button-cancel" class="cancel">Cancelar</a>
								<input type="hidden" name="id" value="<?php echo $_SESSION['id']; ?>" style="width:20px; float:left;">
							</div>
						</form>
					</div>
					<div id="content-section-elements" class="content-table">
						<div class="content-title">
							<span class="showHide">
								<a href="javascript:;" class="show hide-row"><img src="resources/images/row_down.png" height="17" width="17"></a>
								<a href="javascript:;" class="hide"><img src="resources/images/row_up.png" height="17" width="17"></a>
							</span>
							<h2 class="fix-section-title">Otros usuarios</h2>
						</div>
						<div class="holder"></div>
						<?php require_once('tables/table-users.php'); ?>
					</div>
				</div>
			</div>
		</section>
		<!-- end content -->
		<?php require_once('templates/footer.php'); ?>
	</div>
	<!-- end wrap -->