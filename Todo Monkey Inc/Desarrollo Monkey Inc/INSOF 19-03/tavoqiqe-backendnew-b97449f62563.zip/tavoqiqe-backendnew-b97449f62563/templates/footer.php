<!-- footer -->
		<footer id="footer">
			<div class="container">
				<!--<div class="container-footer">
					<span>
						Copyright © 20013 
						<a href="http://www.facebook.com/tavo.qiqe.lucero" target="_blank">TavoQiqe</a>
						</span>
				</div>-->
			</div>
		</footer>
		<!-- end footer -->
		<script src="resources/js/jquery.min.js"></script>
		<script src="resources/js/getDatos.js"></script>
		<script src="resources/js/jquery-ui-1.10.3.custom.min.js"></script>
		<script src="resources/js/jPages.js"></script>
		<script src="resources/js/jquery.alerts.js"></script>
		<script src="resources/js/jquery.flip.js"></script>
		<script src="resources/js/jquery.bpopup.min.js"></script>
		<script src="resources/js/validate-academia.js"></script>
		<script src="resources/js/validate-eventos.js"></script>
		<script src="resources/js/validate-noticias.js"></script>

		<!-- Lengüaje datepicker -->
		<script>
			$(document).ready(function(){
				 $.datepicker.regional['es'] = {
				closeText: 'Cerrar',
				prevText: '<Ant',
				nextText: 'Sig>',
				currentText: 'Hoy',
				monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
				monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
				dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
				dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
				dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
				weekHeader: 'Sm',
				dateFormat: 'dd/mm/yy',
				firstDay: 1,
				isRTL: false,
				showMonthAfterYear: false,
				yearSuffix: ''
			};
			$.datepicker.setDefaults($.datepicker.regional['es']);
			});
		</script>

		<!-- datepicker -->
		<script>
			$(document).ready(function(){
				$("#jdate").datepicker({
					numberOfMonths: 1,
					dateFormat: "DD dd 'de' MM 'del' yy",
				});
			});
		</script>

		<!-- Toggle content -->
		<script>
			$(document).ready(function(){
				$('.show').click(function(){
				$(this).addClass('hide-row');
				$(this).next().removeClass('hide-row');
				$(this).closest('#content-section-elements').animate({'height' : '60px'}, 500);
				});//click .show
				$('.hide').click(function(){
				$(this).addClass('hide-row');
				$(this).prev().removeClass('hide-row');
				$(this).closest('#content-section-elements').css({'height' : 'auto'});
				});//click .hide
			});//ready
		</script>

		<!-- Tooltip -->
		<script>
			$(document).ready(function(){
				$('.link-tooltip').hover(function(){
					$(this).children('.tooltip').css({'display' : 'block'}, 250)
					$(this).children('.tooltip').animate({'top' : '22px'}, 250)
				}, function(){
					$(this).children('.tooltip').css({'display' : 'none' , 'top' : '12px'})
				}
				);
			});
		</script>

		<!-- Eliminar -->
		<script>
		$(document).ready(function(){
			$('.dConfirm').click(function(){
				var id_current = $(this).next().val();
				var table = $(this).attr('id');
				jConfirm('¿Desea eliminar éste registro?', 'BackEnd INSOF', function(r){
					if(r){
						document.location.href = 'functions/delete.php?id='+id_current+'&'+table+'';
					}else{
						false;
					}
				})
			});
		});
		</script>

		<!-- Flip -->
		<script>
			$(document).ready(function(){
				$("#flipPad a:not(.revert)").bind("click", function(){
					window.flipDirection = $(this).attr("rel");
					$("#flipbox").flip({
						direction: $(this).attr("rel"),
						color: "rgba(0,0,0,0)",
						onBefore: function(){$(".revert").show(); $("#flipbox ul.list-qs").html("")}
					})
					return false;
				});
				//Flip Revert
				$("#flipPad a.revert").bind("click", function(){
					$("#flipbox").flip({
						direction: flipDirection,
						color: "rgba(0,0,0,0)",
						onBefore: function(){$(".revert").hide(); $("#flipbox ul.list-qs").html("<span class='span-qs'>Consulta rápida</span>"); $(".title-consultaqs").html("Consulta Rápida")}
					})
					return false;
				});
			});
		</script>

		<!-- Paginación de tablas -->
		<script>
			$(document).ready(function(){
				$("div.holder").jPages({
					containerID : "table-target",
					previous : "←",
					next : "→",
					perPage : 6,
					delay : 20,
				});
			});
		</script>