<?php 
if(!isset($_SESSION)){
	session_start();
}
if(isset($_SESSION['usuario'])){
	header('Location: index.php');
}
?>
<!doctype html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Login | BackEnd</title>
	<link href="../../resources/css/style.css" rel="stylesheet" type="text/css" />
	<link href="../../resources/css/responsive.css" rel="stylesheet" type="text/css" />
</head>
<body class="bg-wrap">
	<!-- wrap -->
	<div class="wrap">
		<!-- container-login -->
		<div class="container-login">
			<!-- content-login -->
			<div class="content-login">
				<div class="login-logo">
					<h1><img src="../../resources/images/logo.png" height="80" width="160" alt=""></h1>
				</div>
				<div class="top-login">
					<h2 class="login-ribbon">
						<span>Por favor ingrese con su cuenta</span>
					</h2>
					<a href="javascript:;" id="popup-trigger" class="new-user">
						<span>Agregar nuevo usuario!</span>
					</a>
				</div>
				<div class="content-login-form clearfix">
					<form action="../../functions/usuario-existente.php" method="post" id="form-login" autocomplete="off">
						<div class="control-group">
							<label class="control-label" for="usuario">Nombre de usuario</label>
							<input class="control-input-login" type="text" name="usuario" id="usuario" autofocus>
							<p id="error-user-login" class="error-message" style="display:none;"><span></span></p>
						</div>
						<div class="control-group">
							<label class="control-label" for="contrasena">Contraseña</label>
							<input class="control-input-login" type="password" name="contrasena" id="contrasena">
							<p id="error-password-login" class="error-message" style="display:none;"><span></span></p>
						</div>
						<input type="submit" name="entrar" id="button-login" class="button button-login" value="Entrar">
					</form>
				</div>
			</div>
			<!-- end content-login -->
		</div>
		<!-- end container-login -->
		<?php require_once('../../new-user.php'); ?>
	</div>
	<!-- end wrap -->
	<script src="../../resources/js/jquery.min.js"></script>
	<script src="../../resources/js/jquery.bpopup.min.js"></script>
	<!--<script src="../../resources/js/validate-login.js"></script>-->
	<script src="../../resources/js/newuser-popup.js"></script>
</body>
</html>