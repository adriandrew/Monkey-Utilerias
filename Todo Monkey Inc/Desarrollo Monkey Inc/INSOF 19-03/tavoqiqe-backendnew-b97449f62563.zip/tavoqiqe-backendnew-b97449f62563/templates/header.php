<?php require_once('functions/session-start.php'); ?>
<?php require_once('conn/conexionServicio.php'); ?>
<?php require_once('functions/name_current_user.php'); ?>
<!doctype html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>ISW | BackEnd</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="resources/css/style.css" rel="stylesheet" type="text/css" />
	<link href="resources/css/responsive.css" rel="stylesheet" type="text/css" />
	<link href="resources/css/jquery-ui-1.10.3.custom.css" rel="stylesheet" type="text/css" />
	<link href="resources/css/jPages.css" rel="stylesheet" type="text/css" />
	<link href="resources/css/animate.css" rel="stylesheet" type="text/css" />
	<link href="resources/css/jquery.alerts.css" rel="stylesheet" type="text/css" />
</head>
<body class="bg-wrap">
	<!-- wrap -->
	<div class="wrap">
		<!-- header -->
		<header id="header">
			<div class="container">
				<div class="top-header clearfix">
					<div class="logo">
						<h1>
							<a href="index.php"><img src="resources/images/logo.png" height="80" width="160" alt=""></a>
						</h1>
					</div>
					<div class="container-box-user">
						<div class="box-user clearfix">
							<div class="avatar-user">
								<?php echo ($_SESSION['sexo'] == 'h') ? '<img src="resources/images/user_male.png" height="32" width="32" alt="">' : '<img src="resources/images/user_female.png" height="32" width="32" alt="">' ?>
							</div>
							<div class="user-info">
								<div class="user-name">
									<span><?php echo $n1." ".$l1; ?></span>
								</div>
								<div class="user-acces">
									<a href="editar-usuarios.php">Editar</a><span>|</span><a href="logout.php">Log out</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<nav id="nav">
					<ul class="navlist flexbox">
						<li><a href="academia.php"><span class="font-icon">U</span><span class="font-link">Academia</span></a></li>
						<li><a href="noticias.php"><span class="font-icon">e</span><span class="font-link">Noticias</span></a></li>
						<li><a href="eventos.php"><span class="font-icon">@</span><span class="font-link">Eventos</span></a></li>
					</ul>
				</nav>
			</div>
		</header>
		<!-- end header -->