<table class="table-academia">
	<thead>
		<tr>
			<th>Nombre</th>
			<th>Cargo</th>
			<th style="width:90px">Teléfono</th>
			<th>E-mail</th>
			<th>Cubículo</th>
			<th>Horario en cubículo</th>
			<?php echo ($_SESSION['nivel'] == '1' ? "<th colspan='2'>Acciones</th>" : "") ?>
		</tr>
	</thead>
	<tbody id="table-target">
		<?php
		mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());
		$consulta = ("SELECT * FROM movil_academia");
		$resConsulta = mysql_query($consulta, $conexionServicio) or die(mysql_error());
		while($row = mysql_fetch_assoc($resConsulta)) { ?>
			<tr>
				<td><?php echo $row['nombre']; ?></td>
				<td><?php echo $row['cargo']; ?></td>
				<td><?php echo $row['telefono']; ?></td>
				<td><?php echo $row['email']; ?></td>
				<td style="text-align:center;"><?php echo $row['cubiculo']; ?></td>
				<td><?php echo $row['hora']; ?></td>
				<?php
				if($_SESSION['nivel'] == '1'){ ?>
					<td>
					<a href="editar-academia.php?id=<?php echo $row['id']; ?>" class="link-tooltip"><img src="resources/images/ico_edit.png"><span class="tooltip">Editar</span></a>
					<a href="javascript:;" class="link-tooltip dConfirm" id="dAcademia" onclick="jConfirm()"><img src="resources/images/ico_delete.png"><span class="tooltip">Eliminar</span></a>
					<input type="hidden" name="id_current" id="id_current" style="width:60px; padding:0; text-align:center;" value="<?php echo $row['id']; ?>" disabled>
					</td>
				<?php } ?>
			</tr>
		<?php } ?>
	</tbody>
</table>