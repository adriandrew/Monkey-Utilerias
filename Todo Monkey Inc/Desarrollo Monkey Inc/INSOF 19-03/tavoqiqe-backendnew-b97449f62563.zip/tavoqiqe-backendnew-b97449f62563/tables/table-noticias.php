<table class="table-eventos">
	<thead>
		<tr>
			<th style="width:200px">Nombre del evento</th>
			<th>Descripción del evento</th>
			<th>Fecha del evento</th>
			<?php echo ($_SESSION['nivel'] == '1' ? "<th colspan='2'>Acciones</th>" : "") ?>
		</tr>
	</thead>
	<tbody id="table-target">
		<?php
		mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());
		$consulta = ("SELECT * FROM movil_noticia");
		$resConsulta = mysql_query($consulta, $conexionServicio) or die(mysql_error());
		while($row = mysql_fetch_assoc($resConsulta)) { ?>
			<tr>
				<td><?php echo $row['nombre']; ?></td>
				<td><?php echo $row['noticia_prev']. ' ...'; ?></td>
				<td><?php echo $row['fecha_str']; ?></td>
				<?php
				if($_SESSION['nivel'] == '1'){ ?>
					<td>
					<a href="editar-noticias.php?id=<?php echo $row['id']; ?>" class="link-tooltip"><img src="resources/images/ico_edit.png"><span class="tooltip">Editar</span></a>
					<a href="javascript:;" class="link-tooltip dConfirm" id="dNoticia" onclick="jConfirm()"><img src="resources/images/ico_delete.png"><span class="tooltip">Eliminar</span></a>
					<input type="hidden" name="id_current" id="id_current" style="width:60px; padding:0; text-align:center;" value="<?php echo $row['id']; ?>" disabled>
					</td>
				<?php } ?>
			</tr>
		<?php } ?>
	</tbody>
</table>