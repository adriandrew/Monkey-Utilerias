<table class="table-academia">
	<thead>
		<tr>
			<th>Nombre</th>
			<th>Email</th>
			<th>Nombre de usuario</th>
			<th>Nivel</th>
			<?php echo ($_SESSION['nivel'] == '1' ? "<th colspan='2'>Acciones</th>" : "") ?>
		</tr>
	</thead>
	<tbody id="table-target">
		<?php
		mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());
		$consulta = ("SELECT * FROM movil_usuarios");
		$resConsulta = mysql_query($consulta, $conexionServicio) or die(mysql_error());
		while($row = mysql_fetch_assoc($resConsulta))
		{
		?>
			<tr>
				<td><?php echo $row['nombre']." ".$row['apellidos']; ?></td>
				<td><?php echo $row['email']; ?></td>
				<td><?php echo $row['usuario']; ?></td>
				<td><?php echo ($row['nivel'] == '1') ? 'Administrador' : 'Usuario' ?></td>
				<?php
				if($_SESSION['nivel'] == '1') { ?>
					<td>
					<a href="editar-usuario.php?id=<?php echo $row['id']; ?>" class="link-tooltip"><img src="resources/images/ico_edit.png"><span class="tooltip">Editar</span></a>
					<a href="javascript:;" class="link-tooltip dConfirm" id="dUsuario" onclick="jConfirm()"><img src="resources/images/ico_delete.png"><span class="tooltip">Eliminar</span></a>
					<input type="hidden" name="id_current" id="id_current" style="width:60px; padding:0; text-align:center;" value="<?php echo $row['id']; ?>" disabled>
					</td>
				<?php } ?>
			</tr>
		<?php } ?>
	</tbody>
</table>