<?php require_once('../conn/conexionServicio.php'); ?>
<?php
if(isset($_POST['registrar']) and $_POST['registrar'] == 'Registrar'){

	mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());

	$insertSql = sprintf("INSERT INTO movil_usuarios (nombre, apellidos, email, sexo, usuario, contrasena, nivel) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s')",
	mysql_real_escape_string(trim($_POST['nombre'])),
	mysql_real_escape_string(trim($_POST['apellidos'])),
	mysql_real_escape_string(trim($_POST['email'])),
	mysql_real_escape_string(trim($_POST['sexo'])),
	mysql_real_escape_string(trim($_POST['usuario'])),
	mysql_real_escape_string(trim($_POST['contrasena'])),
	mysql_real_escape_string(trim($_POST['nivel'])));

	$resInsertSql = mysql_query($insertSql, $conexionServicio) or die(mysql_error());
	header('Location: ../index.php');

}else{
	header('Location: ../index.php');
}
?>