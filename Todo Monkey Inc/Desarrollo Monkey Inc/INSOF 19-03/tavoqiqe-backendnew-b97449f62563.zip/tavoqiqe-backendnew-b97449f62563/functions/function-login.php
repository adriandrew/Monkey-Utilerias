<?php require_once('../conn/conexionServicio.php'); ?>
<?php
if(!isset($_SESSION)){
	session_start();
}
?>
<?php
if(isset($_POST['entrar']) and $_POST['entrar'] == 'Entrar'){

	mysql_select_db($baseDatos, $conexionServicio);
	$consultaLogin = sprintf("SELECT * FROM movil_usuarios WHERE usuario = '%s' AND contrasena = '%s'",
	mysql_real_escape_string(trim($_POST['usuario'])),
	mysql_real_escape_string(trim($_POST['contrasena'])));

	if($_POST['usuario'] != '%s' and $_POST['contrasena'] != '%s'){
		header('Location: ../login.php');
	}

	$resultConsultaLogin = mysql_query($consultaLogin, $conexionServicio) or die(mysql_error());
	$loggeado = mysql_num_rows($resultConsultaLogin);

	if($loggeado){
		$usuarioValidado = mysql_fetch_assoc($resultConsultaLogin);
		$_SESSION['id'] = $usuarioValidado['id'];
		$_SESSION['nombre'] = $usuarioValidado['nombre'];
		$_SESSION['apellidos'] = $usuarioValidado['apellidos'];
		$_SESSION['email'] = $usuarioValidado['email'];
		$_SESSION['sexo'] = $usuarioValidado['sexo'];
		$_SESSION['usuario'] = $usuarioValidado['usuario'];
		$_SESSION['contrasena'] = $usuarioValidado['contrasena'];
		$_SESSION['nivel'] = $usuarioValidado['nivel'];
		header('Location: ../index.php');
	}
}
?>