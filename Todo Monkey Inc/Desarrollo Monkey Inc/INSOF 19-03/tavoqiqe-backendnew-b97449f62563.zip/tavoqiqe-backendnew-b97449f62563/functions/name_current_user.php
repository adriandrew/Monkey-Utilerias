<!--<?php //require_once('session-start.php'); ?>-->
<?php
//Explode nombre
$nameExplode = list($n1,$n2,$n3) = explode(" ", $_SESSION['nombre']);
//print_r($nameExplode);
//echo "<br>";
//echo "Nombre: " .$n1." ".$n2." ".$n3."<br>";

//Explode appelido
$lastnameExplode = list($l1,$l2,$l3) = explode(" ", $_SESSION['apellidos']);
//print_r($lastnameExplode);
//echo "<br>";
//echo "Apellido: " .$l1." ".$l2." ".$l3."<br>";
?>