<?php require_once('conn/conexionServicio.php'); ?>
<?php
mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());
//Contar Usuarios
$consultaUsuarios = "SELECT * FROM movil_usuarios";
$resultConsultaUsuarios = mysql_query($consultaUsuarios) or die(mysql_error());
$countUsuarios = mysql_num_rows($resultConsultaUsuarios);
//Contar Academia
$consultaAcademia = "SELECT * FROM movil_academia";
$resultConsultaAcademia = mysql_query($consultaAcademia) or die(mysql_error());
$countAcademia = mysql_num_rows($resultConsultaAcademia);
//Contar Noticias
$consultaNoticias = "SELECT * FROM movil_noticia";
$resultConsultaNoticias = mysql_query($consultaNoticias) or die(mysql_error());
$countNoticias = mysql_num_rows($resultConsultaNoticias);
//Contar Eventos
$consultaEventos = "SELECT * FROM movil_evento";
$resultConsultaEventos = mysql_query($consultaEventos) or die(mysql_error());
$countEventos = mysql_num_rows($resultConsultaEventos);
?>