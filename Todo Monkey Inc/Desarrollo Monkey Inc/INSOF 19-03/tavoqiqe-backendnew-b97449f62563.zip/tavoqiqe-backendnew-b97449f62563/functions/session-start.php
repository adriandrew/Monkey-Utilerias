<?php 
if(!isset($_SESSION))
{
	session_start();
}
//if(!isset($_SESSION['usuario']))
//{
//	header('Location: login.php');
//}
//if(isset($_GET['logOut']) and $_GET['logOut'] == true)
//{
	//session_destroy();header('Location: login.php');
//} 
?>