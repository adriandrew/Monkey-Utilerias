<meta charset="utf-8">
<?php
echo "Fecha formulario: " .$_POST['fecha']."<br>";

$formattedDate = list($D,$d,$lt1,$M,$lt2,$y) = explode(" ", $_POST['fecha']);
echo "Fecha separada: " .$D.$d.$lt1.$M.$lt2.$y. "<br>";
if($M == 'Enero'){$M='01';}if($M == 'Febrero'){$M='02';}if($M == 'Marzo'){$M='03';}if($M == 'Abril'){$M='04';}if($M == 'Mayo'){$M='05';}if($M == 'Junio'){$M='06';}
if($M == 'Julio'){$M='07';}if($M == 'Agosto'){$M='08';}if($M == 'Septiembre'){$M='09';}if($M == 'Octubre'){$M='10';}if($M == 'Noviembre'){$M='11';}if($M == 'Diciembre'){$M='12';}
echo "Día: " .$d. " - Mes: " .$M. " - Año: " .$y. "<br>";
$timestamp = mktime(0,0,0,$M,$d,$y);
$fecha = date("Y-m-d", $timestamp);
echo "Fecha final: " .$fecha. "<br>";
//print_r($formattedDate);
?>