<?php require_once('../conn/conexionServicio.php'); ?>
<?php
if(isset($_POST['guardar']) and $_POST['guardar'] == "Guardar"){

	$ruta = 'C:/xampp/htdocs/BackEndNew/resources/images/uploads/'.$_FILES['imagen']['name'];
	$urlimagen = 'resources/images/uploads/'.$_FILES['imagen']['name'];
	move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta);

	$formattedDate = list($D,$d,$lt1,$M,$lt2,$y) = explode(" ", $_POST['fecha']);
	if($M == 'Enero'){$M='01';}if($M == 'Febrero'){$M='02';}if($M == 'Marzo'){$M='03';}if($M == 'Abril'){$M='04';}if($M == 'Mayo'){$M='05';}if($M == 'Junio'){$M='06';}
	if($M == 'Julio'){$M='07';}if($M == 'Agosto'){$M='08';}if($M == 'Septiembre'){$M='09';}if($M == 'Octubre'){$M='10';}if($M == 'Noviembre'){$M='11';}if($M == 'Diciembre'){$M='12';}
	$timestamp = mktime(0,0,0,$M,$d,$y);
	$fecha = date("Y-m-d", $timestamp);

	mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());

	$insertSql = sprintf("INSERT INTO movil_noticia (nombre, noticia, noticia_prev, fecha, fecha_str, imagen) VALUES ('%s', '%s', '%s', '%s', '%s', '%s')",
	mysql_real_escape_string(trim($_POST['nombre'])),
	mysql_real_escape_string(trim(nl2br($_POST['noticia']))),
	mysql_real_escape_string(trim($_POST['noticia'])),
	mysql_real_escape_string(trim($fecha)),
	mysql_real_escape_string(trim($_POST['fecha'])),
	mysql_real_escape_string(trim($urlimagen)));

	$resInsertSql = mysql_query($insertSql, $conexionServicio) or die(mysql_error());
	header('Location: ../noticias.php');
}
?>