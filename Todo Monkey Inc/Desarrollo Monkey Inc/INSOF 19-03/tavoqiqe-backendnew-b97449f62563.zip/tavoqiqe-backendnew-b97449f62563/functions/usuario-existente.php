<meta charset="utf-8">
<?php require_once('../conn/conexionServicio.php'); ?>
<?php
mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());
$consulta = sprintf("SELECT usuario FROM movil_usuarios WHERE usuario = '%s'",
mysql_real_escape_string(trim($_POST['usuario'])));
$resConsulta = mysql_query($consulta, $conexionServicio) or die(mysql_error());
$ValidateUser = mysql_num_rows($resConsulta);
if($ValidateUser > 0){
	echo "Usuario ocupado";
}else{
	echo "Usuario disponible";
}
?>