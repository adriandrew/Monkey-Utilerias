<?php require_once('../conn/conexionServicio.php'); ?>
<?php

mysql_select_db($baseDatos, $conexionServicio) or die (mysql_error());

$qConsulta = sprintf("SELECT * FROM %s",
mysql_real_escape_string($_GET['tabla']));

$resQConsulta = mysql_query($qConsulta, $conexionServicio) or die (mysql_error());

$listado = array();

while($item = mysql_fetch_assoc($resQConsulta)){
$listado[] = $item;
}

header('Content-type: application/json; charset=utf-8');
header("acces-control-allow-origin: *");

$datosJSON = json_encode(array('tabla' => $_GET['tabla'], 'items' => $listado, 'total_results' => mysql_num_rows($resQConsulta)));

echo isset($_GET['callback'])
		? "{$_GET['callback']}($datosJSON)"
		: $datosJSON;

@mysql_close($conexionServicio);

?>