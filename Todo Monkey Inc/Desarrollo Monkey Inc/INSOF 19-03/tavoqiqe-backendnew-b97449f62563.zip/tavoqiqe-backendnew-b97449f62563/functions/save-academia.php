<?php require_once('../conn/conexionServicio.php'); ?>
<?php
if(isset($_POST['guardar']) and $_POST['guardar'] == 'Guardar'){

	mysql_select_db($baseDatos, $conexionServicio);

	$ruta = 'C:/xampp/htdocs/BackEndNew/resources/images/uploads/'.$_FILES['imagen']['name'];
	$urlimagen = 'resources/images/uploads/'.$_FILES['imagen']['name'];
	move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta);

	$insertSql = sprintf("INSERT INTO movil_academia (nombre, cargo, cubiculo, hora, telefono, email, area, certificacion, imagen) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')",
	mysql_real_escape_string(trim($_POST['nombre'])),
	mysql_real_escape_string(trim($_POST['cargo'])),
	mysql_real_escape_string(trim($_POST['cubiculo'])),
	mysql_real_escape_string(trim($_POST['hora'])),
	mysql_real_escape_string(trim($_POST['telefono'])),
	mysql_real_escape_string(trim($_POST['email'])),
	mysql_real_escape_string(trim($_POST['area'])),
	mysql_real_escape_string(trim($_POST['certificacion'])),
	mysql_real_escape_string(trim($urlimagen)));

	$resInsertSql = mysql_query($insertSql, $conexionServicio);
	header('Location: ../academia.php');
}
?>