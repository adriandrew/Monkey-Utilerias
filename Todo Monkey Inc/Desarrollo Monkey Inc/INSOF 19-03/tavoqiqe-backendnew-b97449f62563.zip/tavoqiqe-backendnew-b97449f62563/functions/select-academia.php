<?php require_once('conn/conexionServicio.php'); ?>
<?php
if(isset($_GET['id'])){

	mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());
	$consulta = sprintf("SELECT * FROM movil_academia WHERE id = %d",
	mysql_real_escape_string(trim($_GET['id'])));
	$resConsulta = mysql_query($consulta, $conexionServicio) or die(mysql_error());
	$cargar = mysql_fetch_assoc($resConsulta);

}
?>