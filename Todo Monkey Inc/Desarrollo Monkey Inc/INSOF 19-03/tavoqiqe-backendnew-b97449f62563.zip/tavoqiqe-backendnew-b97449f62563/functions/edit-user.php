<?php require_once('../conn/conexionServicio.php'); ?>
<?php
if(isset($_POST['editar']) and $_POST['editar'] == 'Editar'){

	mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());

	$editar = sprintf("UPDATE movil_usuarios SET nombre='%s', apellidos='%s', email='%s', sexo='%s', usuario='%s', contrasena='%s', nivel='%s' WHERE id=%d",
	mysql_real_escape_string(trim($_POST['nombre'])),
	mysql_real_escape_string(trim($_POST['apellidos'])),
	mysql_real_escape_string(trim($_POST['email'])),
	mysql_real_escape_string(trim($_POST['sexo'])),
	mysql_real_escape_string(trim($_POST['usuario'])),
	mysql_real_escape_string(trim($_POST['contrasena'])),
	mysql_real_escape_string(trim($_POST['nivel'])),
	mysql_real_escape_string(trim($_POST['id'])));

	$resEditar = mysql_query($editar, $conexionServicio) or die(mysql_error());

	if(isset($_GET['btl'])){
		header('Location: ../index.php');
	}else{
		header('Location: ../editar-usuarios.php');
	}
}
?>