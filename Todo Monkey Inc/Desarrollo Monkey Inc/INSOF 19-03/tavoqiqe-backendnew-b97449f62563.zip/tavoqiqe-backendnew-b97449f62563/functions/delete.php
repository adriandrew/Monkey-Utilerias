<?php require_once('../conn/conexionServicio.php'); ?>
<?php
//Eliminar academia
if(isset($_GET['dAcademia'])){

	mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());
	$deleteSql = sprintf("DELETE FROM movil_academia WHERE id = %d",
	mysql_real_escape_string(trim($_GET['id'])));
	$resDeleteSql = mysql_query($deleteSql, $conexionServicio) or die(mysql_error());
	header('Location: ../academia.php');

}
//Eliminar noticia
if(isset($_GET['dNoticia'])){

	mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());
	$deleteSql = sprintf("DELETE FROM movil_noticia WHERE id = %d",
	mysql_real_escape_string(trim($_GET['id'])));
	$resDeleteSql = mysql_query($deleteSql, $conexionServicio) or die(mysql_error());
	header('Location: ../noticias.php');

}
//Eliminar evento
if(isset($_GET['dEvento'])){

	mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());
	$deleteSql = sprintf("DELETE FROM movil_evento WHERE id = %d",
	mysql_real_escape_string(trim($_GET['id'])));
	$resDeleteSql = mysql_query($deleteSql, $conexionServicio) or die(mysql_error());
	header('Location: ../eventos.php');

}
//Eliminar usuario
if(isset($_GET['dUsuario'])){

	mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());
	$deleteSql = sprintf("DELETE FROM movil_usuarios WHERE id = %d",
	mysql_real_escape_string(trim($_GET['id'])));
	$resDeleteSql = mysql_query($deleteSql, $conexionServicio) or die(mysql_error());
	header('Location: ../editar-usuarios.php');

}
?>