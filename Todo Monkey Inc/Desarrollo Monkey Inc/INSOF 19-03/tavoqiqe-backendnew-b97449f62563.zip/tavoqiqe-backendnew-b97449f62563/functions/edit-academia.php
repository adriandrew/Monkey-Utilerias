<?php require_once('../conn/conexionServicio.php'); ?>
<?php
if(isset($_POST['editar']) and $_POST['editar'] == 'Editar'){

	mysql_select_db($baseDatos, $conexionServicio) or die(mysql_error());

	$editar = sprintf("UPDATE movil_academia SET nombre='%s', cargo='%s', cubiculo='%s', hora='%s', telefono='%s', email='%s', area='%s', certificacion='%s' WHERE id=%d",
	mysql_real_escape_string(trim($_POST['nombre'])),
	mysql_real_escape_string(trim($_POST['cargo'])),
	mysql_real_escape_string(trim($_POST['cubiculo'])),
	mysql_real_escape_string(trim($_POST['hora'])),
	mysql_real_escape_string(trim($_POST['telefono'])),
	mysql_real_escape_string(trim($_POST['email'])),
	mysql_real_escape_string(trim($_POST['area'])),
	mysql_real_escape_string(trim($_POST['certificacion'])),
	mysql_real_escape_string(trim($_POST['id'])));

	$resEditar = mysql_query($editar, $conexionServicio) or die(mysql_error());
	header('Location: ../academia.php');
}
?>