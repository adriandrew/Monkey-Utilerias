<?php
$server = 'localhost'; //iswug.db.4415871.hostedresource.com
$baseDatos = 'iswug'; //iswug
$user = 'root'; //iswug
$pass = 'root'; //Ing3niero

$conexionServicio = mysql_connect($server, $user, $pass) or trigger_error(mysql_error, E_USER_ERROR);
mysql_query("SET NAMES 'utf8'");
?>