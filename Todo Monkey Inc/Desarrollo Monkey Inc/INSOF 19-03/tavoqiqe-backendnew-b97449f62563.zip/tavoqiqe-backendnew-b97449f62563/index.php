<?php
	$minUserLevel = 1;
	$cfgProgDir = 'resources/phpSecurePages/';
	include($cfgProgDir . "secure.php");
?>
<?php require_once('functions/count-status.php'); ?>
<?php require_once('templates/header.php'); ?>

		<section id="content">
			<div class="container">
				<div class="content-index clearfix">
					<div class="content-index-left">
						<div class="status">
							<div class="header-status">
								<div class="ico-status"><img src="resources/images/ico_status.png" alt=""></div>
								<h3 class="indexh3">Estadísticas</h3>
							</div>
							<p class="indexp">Información Reciente</p>
							<div class="status-info">
								<ul class="list-status">
									<li>
										<div class="row-status">
											<div class="ico-row"><img src="resources/images/ico_status_usuarios.png" height="32" width="32" alt=""></div>
											<span class="num-status"><?php echo $countUsuarios; ?></span>
											<span class="title-status">Usuarios</span>
										</div>
									</li>
									<li>
										<div class="row-status">
											<div class="ico-row"><img src="resources/images/ico_status_academia.png" alt=""></div>
											<span class="num-status"><?php echo $countAcademia; ?></span>
											<span class="title-status">Docentes</span>
										</div>
									</li>
									<li>
										<div class="row-status">
											<div class="ico-row"><img src="resources/images/ico_status_noticias.png" alt=""></div>
											<span class="num-status"><?php echo $countNoticias; ?></span>
											<span class="title-status">Noticias</span>
										</div>
									</li>
									<li>
										<div class="row-status">
											<div class="ico-row"><img src="resources/images/ico_status_eventos.png" alt=""></div>
											<span class="num-status"><?php echo $countEventos; ?></span>
											<span class="title-status">Eventos</span>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="content-index-right">
						<div class="header-status" style="border:1px solid #ccc">
							<div class="ico-status"><img src="resources/images/ico_consulta.png" alt=""></div>
								<h3 class="indexh3 title-consultaqs">Consulta Rápida</h3>
								<div id="flipbox">
									<ul class="list-qs">
										<span class="span-qs">Consulta rápida</span>
										<!--<li>
											<div class="thumb-qs"><img src="resources/images/happy-face.png" height="80" width="80" alt=""></div>
											<div class="top-qs">
												<p>Nombre</p>
											</div>
											<div class="bottom-qs">
												<p>Descripción</p>
											</div>
										</li>-->
									</ul>
								</div>
								<div id="flipPad">
									<a href="javascript:;" id="movil_usuarios" class="getLista" rel="rl">usuarios</a>
									<a href="javascript:;" id="movil_academia" class="getLista" rel="bt">academia</a>
									<a href="javascript:;" id="movil_noticia" class="getLista" rel="tb">noticias</a>
									<a href="javascript:;" id="movil_evento" class="getLista" rel="lr">eventos</a>
									<a href="javascript:;" class="revert">Volver</a>
								</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<?php require_once('templates/footer.php'); ?>
	</div>
	<!-- end wrap -->
</body>
</html>