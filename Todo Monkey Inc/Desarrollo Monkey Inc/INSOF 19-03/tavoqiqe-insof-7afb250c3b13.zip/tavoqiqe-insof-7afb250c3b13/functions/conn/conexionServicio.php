<?php 
$server = 'iswug.db.4415871.hostedresource.com';
$baseDatos = 'iswug';
$user = 'iswug';
$pass = 'Ing3niero';

$conexionServicio = mysql_connect($server, $user, $pass) or trigger_error(mysql_error, E_USER_ERROR);
mysql_query("SET NAMES 'utf8'");
?>