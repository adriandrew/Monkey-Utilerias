<?php
require_once('../conn/conexionServicio.php');

mysql_select_db($baseDatos, $conexionServicio) or die ('Imposible conectar con la base de datos');

$qDetalle = sprintf("SELECT * FROM %s WHERE id=%d",
	mysql_real_escape_string($_GET['tipo']),mysql_real_escape_string($_GET['itemID']));

$resQDetalle = mysql_query($qDetalle, $conexionServicio) or die ('No se puede ejecutar la consulta');

$detalle = array();

while($item = mysql_fetch_assoc($resQDetalle)){
	$detalle[] = $item;
}

header('Content-type: application/json; charset=utf-8');
header("acces-control-allow-origin: *");

$datosJSON = json_encode(array('tipo' => $_GET['tipo'], 'ID' => $_GET['itemID'], 'items' => $detalle, 'total_results' => mysql_num_rows($resQDetalle)));

echo isset($_GET['callback'])
		? "{$_GET['callback']}($datosJSON)"
		: $datosJSON;
		
@mysql_close($conexionServicio);

?>