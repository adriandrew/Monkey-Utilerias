<?php 
require_once('../conn/conexionServicio.php');

mysql_select_db($baseDatos, $conexionServicio) or die ('Imposible conectar con la base de datos');

$qConsulta = sprintf("SELECT * FROM %s",
	mysql_real_escape_string($_GET['tipo']));

$resQConsulta = mysql_query($qConsulta, $conexionServicio) or die ('No se puede ejecutar la consulta');

$listado = array();

while($item = mysql_fetch_assoc($resQConsulta)){
	$listado[] = $item;
}

header('Content-type: application/json; charset=utf-8');
header("acces-control-allow-origin: *");

$datosJSON = json_encode(array('tipo' => $_GET['tipo'], 'items' => $listado, 'total_results' => mysql_num_rows($resQConsulta)));

echo isset($_GET['callback'])
		? "{$_GET['callback']}($datosJSON)"
		: $datosJSON;
		
@mysql_close($conexionServicio);
?>