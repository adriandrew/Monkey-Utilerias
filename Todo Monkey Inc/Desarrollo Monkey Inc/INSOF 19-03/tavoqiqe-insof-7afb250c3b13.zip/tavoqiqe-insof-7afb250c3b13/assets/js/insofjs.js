$(document).delegate('#home a.getLista', 'click', getLista);
$(document).delegate('#listado a.getDetalle', 'click', getDetalle);
$(document).delegate('#listado', 'pagebeforeshow', loadLista);
$(document).delegate('#home', 'pagebeforeshow', cleanLista);

function getLista() {

	window.tipo = $(this).attr('id');
	$.getJSON('http://movil.iswug.net/insofnew/functions/services/searchInsof.php?tipo='+tipo+'&callback=?', function(json) {
		console.log(json);
		window.listadoI = json;
		injectLista(listadoI)
	});

}//getLista

function injectLista(listado) {

	if(tipo == 'movil_academia') {
		$.each(listado.items, function(clave, valor) {
			$('.title').html('Academia');
			$('.lista-resultado').append('<li><a href="academia.html" id="'+valor.id+'" class="getDetalle"><img src="'+valor.imagen+'" class="ui-li-thumb"><h3>'+valor.nombre+'</h3><p>'+valor.cargo+'</p></a></li>');
		});
	}
	if(tipo == 'movil_evento') {
		$.each(listado.items, function(clave, valor) {
			$('.title').html('Eventos');
			$('.lista-resultado').append('<li><a href="eventos.html" id="'+valor.id+'" class="getDetalle"><img src="'+valor.imagen+'" class="ui-li-thumb"><h3>'+valor.nombre+'</h3><p>'+valor.fecha_str+'</p></a></li>');
		});
	}
	if(tipo == 'movil_noticia') {
		$.each(listado.items, function(clave, valor) {
			$('.title').html('Noticias');
			$('.lista-resultado').append('<li><a href="noticias.html" id="'+valor.id+'" class="getDetalle"><img src="'+valor.imagen+'" class="ui-li-thumb"><h3>'+valor.nombre+'</h3><p>'+valor.fecha_str+'</p></a></li>');
		});
	}

	$('.lista-resultado').listview();

}//injectLista

function getDetalle() {

	var itemID = $(this).attr('id');
	if(tipo == 'movil_academia') {
		$.getJSON('http://movil.iswug.net/insofnew/functions/services/getDetalle.php?tipo='+tipo+'&itemID='+itemID+'&callback=?', function(detalle) {
			console.log(detalle);
			$('.img-docente').attr('src', detalle.items[0].imagen);
			$('.nombre').html(detalle.items[0].nombre);
			$('.cargo').html(detalle.items[0].cargo);
			$('.email').append(detalle.items[0].email);
			$('.telefono').append(detalle.items[0].telefono);
			$('.cubiculo').append(detalle.items[0].cubiculo);
			$('.horario').append(detalle.items[0].hora);

			var iString = detalle.items[0].area, 			interes = iString.split('-');
			var eString = detalle.items[0].certificacion, 	especialidad = eString.split('-');

			for(var i=0;i<interes.length;i++) {
				$('.lista-interes').append('<li>'+interes[i]+'</li>');
			}
			for(var i=0;i<especialidad.length;i++) {
				$('.lista-especialidad').append('<li>'+especialidad[i]+'</li>');
			}

		});
	}
	if(tipo == 'movil_evento') {
		$.getJSON('http://movil.iswug.net/insofnew/functions/services/getDetalle.php?tipo='+tipo+'&itemID='+itemID+'&callback=?', function(detalle) {
			console.log(detalle);
			$('.img-evento').attr('src', detalle.items[0].imagen);
			$('.evento').html(detalle.items[0].nombre);
			$('.fecha').html(detalle.items[0].fecha_str);
			$('.descripcion').html(detalle.items[0].evento);
		});

	}
	if(tipo == 'movil_noticia') {
		$.getJSON('http://movil.iswug.net/insofnew/functions/services/getDetalle.php?tipo='+tipo+'&itemID='+itemID+'&callback=?', function(detalle) {
			console.log(detalle);
			$('.img-noticia').attr('src', detalle.items[0].imagen);
			$('.noticia').html(detalle.items[0].nombre);
			$('.fecha').html(detalle.items[0].fecha_str);
			$('.descripcion').html(detalle.items[0].noticia);
		});

	}

}//getDetalle

function loadLista() {

	if('listadoI' in window) {
		injectLista(listadoI);
	}

}//loadLista

function cleanLista() {

	delete window.listadoI;

}//cleanLista